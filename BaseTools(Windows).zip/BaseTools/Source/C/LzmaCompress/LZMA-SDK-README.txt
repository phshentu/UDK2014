LzmaCompress is based on the LZMA SDK 4.65.  LZMA SDK 4.65
was placed in the public domain on 2009-02-03.  It was
released on the http://www.7-zip.org/sdk.html website.