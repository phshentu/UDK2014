#define PLATFORM  "UEFI"
#define DATE      "Mon Mar 8 14:17:05 PDT 2010"
