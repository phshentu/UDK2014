# Ebc, Ia32, Ipf, X64
  The binaries in this package currently are built from EDK2 release: MdePkg and BaseTools (r15860), FatPkg (r86)
  The binaries are built with no debug info (RELEASE TARGET).
  The Component Name 2 Protocol and Unicode Collation 2 Protocol are supported.

# ARM
  The binaries in this package currently are built from EDK2 release: MdePkg and BaseTools (r13646), FatPkg (r71)
  The binaries are built with no debug info (RELEASE TARGET).
  Build Instructions: http://sourceforge.net/apps/mediawiki/tianocore/index.php?title=ArmPkg/Binaries
